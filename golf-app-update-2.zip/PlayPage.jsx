import { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { useAuth } from '../hooks/useAuth'
import { supabase } from '../lib/supabase'
import { stablefordPoints, scoreLabel, strokesReceived } from '../lib/scoring'

const TABS = ['Leaderboard', 'Scorecard', 'Enter']

export default function PlayPage() {
  const { roundId } = useParams()
  const { user } = useAuth()
  const navigate = useNavigate()

  const [tab, setTab] = useState('Enter')
  const [round, setRound] = useState(null)
  const [holes, setHoles] = useState([])
  const [players, setPlayers] = useState([])
  const [scores, setScores] = useState([])
  const [loading, setLoading] = useState(true)

  // Score entry state
  const [selectedHole, setSelectedHole] = useState(1)
  const [grossScore, setGrossScore] = useState(4)
  const [saving, setSaving] = useState(false)
  const [saveMsg, setSaveMsg] = useState('')

  useEffect(() => {
    fetchAll()

    const sub = supabase
      .channel(`play-${roundId}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'scores' }, fetchScores)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'round_players', filter: `round_id=eq.${roundId}` }, fetchPlayers)
      .subscribe()

    return () => supabase.removeChannel(sub)
  }, [roundId])

  // When hole changes, pre-fill with par or existing score
  useEffect(() => {
    const hole = holes.find(h => h.hole_number === selectedHole)
    if (!hole) return
    const myPlayer = players.find(p => p.profile_id === user.id)
    if (!myPlayer) return
    const existing = scores.find(s => s.round_player_id === myPlayer.id && s.hole?.hole_number === selectedHole)
    setGrossScore(existing ? existing.gross_score : hole.par)
  }, [selectedHole, holes, scores, players])

  async function fetchAll() {
    await Promise.all([fetchRound(), fetchPlayers()])
    setLoading(false)
  }

  async function fetchRound() {
    const { data } = await supabase
      .from('rounds')
      .select('*, course:courses(name, par, holes(*))')
      .eq('id', roundId)
      .single()
    if (data) {
      setRound(data)
      const sorted = (data.course?.holes ?? []).sort((a, b) => a.hole_number - b.hole_number)
      setHoles(sorted)
      if (sorted.length) setGrossScore(sorted[0].par)
    }
  }

  async function fetchPlayers() {
    const { data } = await supabase
      .from('round_players')
      .select('*, profile:profiles(display_name)')
      .eq('round_id', roundId)
    if (data) {
      setPlayers(data)
      await fetchScores(data)
    }
  }

  async function fetchScores(currentPlayers) {
    const pts = currentPlayers ?? players
    if (!pts.length) return
    const { data } = await supabase
      .from('scores')
      .select('*, hole:holes(hole_number, par, stroke_index)')
      .in('round_player_id', pts.map(p => p.id))
    setScores(data ?? [])
  }

  async function saveScore() {
    const myPlayer = players.find(p => p.profile_id === user.id)
    const hole = holes.find(h => h.hole_number === selectedHole)
    if (!myPlayer || !hole) return

    setSaving(true)
    setSaveMsg('')

    const existing = scores.find(
      s => s.round_player_id === myPlayer.id && s.hole?.hole_number === selectedHole
    )

    const payload = {
      round_player_id: myPlayer.id,
      hole_id: hole.id,
      gross_score: grossScore,
    }

    let error
    if (existing) {
      ({ error } = await supabase.from('scores').update({ gross_score: grossScore }).eq('id', existing.id))
    } else {
      ({ error } = await supabase.from('scores').insert(payload))
    }

    if (!error) {
      setSaveMsg('Saved!')
      setTimeout(() => setSaveMsg(''), 2000)
      // Auto advance to next hole
      if (selectedHole < 18) setSelectedHole(h => h + 1)
    }
    setSaving(false)
  }

  // Compute leaderboard
  function getPlayerStats(player) {
    const playerScores = scores.filter(s => s.round_player_id === player.id)
    let totalPoints = 0
    let totalGross = 0
    let holesPlayed = 0

    playerScores.forEach(s => {
      if (!s.hole) return
      const pts = stablefordPoints(s.gross_score, s.hole.par, s.hole.stroke_index, player.playing_handicap)
      totalPoints += pts
      totalGross += s.gross_score
      holesPlayed++
    })

    return { totalPoints, totalGross, holesPlayed, scores: playerScores }
  }

  function getLeaderboard() {
    return players
      .map(p => ({ ...p, ...getPlayerStats(p) }))
      .sort((a, b) => b.totalPoints - a.totalPoints)
  }

  function getScoreColor(gross, par) {
    const diff = gross - par
    if (diff <= -2) return 'var(--green-500)'
    if (diff === -1) return 'var(--green-500)'
    if (diff === 0) return 'var(--gray-500)'
    if (diff === 1) return 'var(--amber-500)'
    return 'var(--red-500)'
  }

  const myPlayer = players.find(p => p.profile_id === user.id)
  const currentHole = holes.find(h => h.hole_number === selectedHole)
  const leaderboard = getLeaderboard()

  if (loading) return (
    <div className="page" style={{ paddingTop: 80, textAlign: 'center', color: 'var(--gray-500)' }}>
      Loading round…
    </div>
  )

  return (
    <div style={{ maxWidth: 480, margin: '0 auto', paddingBottom: 40 }}>

      {/* Header */}
      <div style={{ background: 'var(--green-700)', padding: '16px 16px 0', color: 'white' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
          <div>
            <p style={{ fontSize: 12, opacity: 0.7, marginBottom: 2 }}>{round?.course?.name}</p>
            <h1 style={{ fontSize: 18, fontWeight: 600 }}>{round?.name}</h1>
          </div>
          <div style={{ textAlign: 'right' }}>
            <p style={{ fontSize: 11, opacity: 0.7 }}>your points</p>
            <p style={{ fontSize: 28, fontWeight: 700, fontFamily: 'var(--font-mono)', lineHeight: 1 }}>
              {myPlayer ? getPlayerStats(myPlayer).totalPoints : 0}
            </p>
          </div>
        </div>

        {/* Tabs */}
        <div style={{ display: 'flex', gap: 4 }}>
          {TABS.map(t => (
            <button
              key={t}
              onClick={() => setTab(t)}
              style={{
                flex: 1,
                padding: '8px 0',
                fontSize: 13,
                fontWeight: 500,
                background: 'none',
                border: 'none',
                color: tab === t ? 'white' : 'rgba(255,255,255,0.6)',
                borderBottom: tab === t ? '2px solid white' : '2px solid transparent',
                cursor: 'pointer',
                transition: 'all 0.15s',
              }}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      <div style={{ padding: '16px' }}>

        {/* LEADERBOARD TAB */}
        {tab === 'Leaderboard' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {leaderboard.map((player, rank) => (
              <div
                key={player.id}
                className="card"
                style={{
                  padding: '12px 16px',
                  border: player.profile_id === user.id ? '1.5px solid var(--green-500)' : undefined,
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <div style={{ fontSize: 18, fontWeight: 700, fontFamily: 'var(--font-mono)', color: 'var(--gray-300)', width: 24 }}>
                    {rank + 1}
                  </div>
                  <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'var(--green-100)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, fontWeight: 600, color: 'var(--green-700)', flexShrink: 0 }}>
                    {player.profile?.display_name?.[0]?.toUpperCase() ?? '?'}
                  </div>
                  <div style={{ flex: 1 }}>
                    <p style={{ fontSize: 15, fontWeight: 500 }}>{player.profile?.display_name}</p>
                    <p style={{ fontSize: 12, color: 'var(--gray-500)' }}>
                      {player.holesPlayed} hole{player.holesPlayed !== 1 ? 's' : ''} · hcp {player.playing_handicap}
                    </p>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <p style={{ fontSize: 24, fontWeight: 700, fontFamily: 'var(--font-mono)', color: 'var(--green-700)', lineHeight: 1 }}>
                      {player.totalPoints}
                    </p>
                    <p style={{ fontSize: 11, color: 'var(--gray-500)' }}>pts</p>
                  </div>
                </div>

                {/* Mini hole-by-hole dots */}
                {player.holesPlayed > 0 && (
                  <div style={{ display: 'flex', gap: 3, marginTop: 10, flexWrap: 'wrap' }}>
                    {holes.map(hole => {
                      const s = player.scores.find(sc => sc.hole?.hole_number === hole.hole_number)
                      const pts = s ? stablefordPoints(s.gross_score, hole.par, hole.stroke_index, player.playing_handicap) : null
                      return (
                        <div
                          key={hole.hole_number}
                          title={`Hole ${hole.hole_number}: ${s ? `${s.gross_score} (${pts} pts)` : 'not played'}`}
                          style={{
                            width: 22, height: 22,
                            borderRadius: 4,
                            background: pts === null ? 'var(--gray-100)' : pts >= 3 ? '#1D9E75' : pts === 2 ? 'var(--green-100)' : pts === 1 ? 'var(--amber-100)' : 'var(--red-100)',
                            display: 'flex', alignItems: 'center', justifyContent: 'center',
                            fontSize: 10, fontWeight: 600,
                            color: pts === null ? 'var(--gray-300)' : pts >= 3 ? 'white' : pts === 2 ? 'var(--green-700)' : pts === 1 ? 'var(--amber-500)' : 'var(--red-500)',
                          }}
                        >
                          {pts !== null ? pts : '·'}
                        </div>
                      )
                    })}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* SCORECARD TAB */}
        {tab === 'Scorecard' && (
          <div>
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
                <thead>
                  <tr>
                    <th style={{ textAlign: 'left', padding: '8px 6px', color: 'var(--gray-500)', fontWeight: 500, borderBottom: '1px solid var(--gray-300)' }}>Hole</th>
                    <th style={{ textAlign: 'center', padding: '8px 6px', color: 'var(--gray-500)', fontWeight: 500, borderBottom: '1px solid var(--gray-300)' }}>Par</th>
                    <th style={{ textAlign: 'center', padding: '8px 6px', color: 'var(--gray-500)', fontWeight: 500, borderBottom: '1px solid var(--gray-300)' }}>SI</th>
                    {players.map(p => (
                      <th key={p.id} style={{ textAlign: 'center', padding: '8px 6px', color: p.profile_id === user.id ? 'var(--green-700)' : 'var(--gray-700)', fontWeight: 600, borderBottom: '1px solid var(--gray-300)', minWidth: 44 }}>
                        {p.profile?.display_name?.split(' ')[0]}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {holes.map(hole => (
                    <tr key={hole.id} style={{ borderBottom: '0.5px solid var(--gray-100)' }}>
                      <td style={{ padding: '7px 6px', fontWeight: 500 }}>{hole.hole_number}</td>
                      <td style={{ padding: '7px 6px', textAlign: 'center', color: 'var(--gray-500)' }}>{hole.par}</td>
                      <td style={{ padding: '7px 6px', textAlign: 'center', color: 'var(--gray-400)' }}>{hole.stroke_index}</td>
                      {players.map(p => {
                        const s = scores.find(sc => sc.round_player_id === p.id && sc.hole?.hole_number === hole.hole_number)
                        return (
                          <td key={p.id} style={{ padding: '7px 6px', textAlign: 'center', fontFamily: 'var(--font-mono)', fontWeight: 500, color: s ? getScoreColor(s.gross_score, hole.par) : 'var(--gray-300)' }}>
                            {s ? s.gross_score : '–'}
                          </td>
                        )
                      })}
                    </tr>
                  ))}
                  {/* Totals row */}
                  <tr style={{ borderTop: '1px solid var(--gray-300)', background: 'var(--gray-50)' }}>
                    <td colSpan={3} style={{ padding: '8px 6px', fontWeight: 600 }}>Total pts</td>
                    {players.map(p => (
                      <td key={p.id} style={{ padding: '8px 6px', textAlign: 'center', fontFamily: 'var(--font-mono)', fontWeight: 700, color: 'var(--green-700)' }}>
                        {getPlayerStats(p).totalPoints}
                      </td>
                    ))}
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ENTER SCORE TAB */}
        {tab === 'Enter' && myPlayer && (
          <div>
            {/* Hole selector */}
            <p style={{ fontSize: 13, color: 'var(--gray-500)', marginBottom: 8 }}>Select hole</p>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 20 }}>
              {holes.map(hole => {
                const s = scores.find(sc => sc.round_player_id === myPlayer.id && sc.hole?.hole_number === hole.hole_number)
                const isSelected = hole.hole_number === selectedHole
                return (
                  <button
                    key={hole.id}
                    onClick={() => setSelectedHole(hole.hole_number)}
                    style={{
                      width: 36, height: 36,
                      borderRadius: 8,
                      border: isSelected ? '2px solid var(--green-600)' : '1px solid var(--gray-300)',
                      background: isSelected ? 'var(--green-600)' : s ? 'var(--green-50)' : 'white',
                      color: isSelected ? 'white' : s ? 'var(--green-700)' : 'var(--gray-700)',
                      fontSize: 13,
                      fontWeight: isSelected || s ? 600 : 400,
                      cursor: 'pointer',
                    }}
                  >
                    {hole.hole_number}
                  </button>
                )
              })}
            </div>

            {/* Hole info */}
            {currentHole && (
              <div style={{ display: 'flex', gap: 10, marginBottom: 20 }}>
                <div className="card" style={{ flex: 1, textAlign: 'center', padding: '10px' }}>
                  <p style={{ fontSize: 11, color: 'var(--gray-500)', marginBottom: 2 }}>PAR</p>
                  <p style={{ fontSize: 22, fontWeight: 700, fontFamily: 'var(--font-mono)' }}>{currentHole.par}</p>
                </div>
                <div className="card" style={{ flex: 1, textAlign: 'center', padding: '10px' }}>
                  <p style={{ fontSize: 11, color: 'var(--gray-500)', marginBottom: 2 }}>STROKE INDEX</p>
                  <p style={{ fontSize: 22, fontWeight: 700, fontFamily: 'var(--font-mono)' }}>{currentHole.stroke_index}</p>
                </div>
                <div className="card" style={{ flex: 1, textAlign: 'center', padding: '10px' }}>
                  <p style={{ fontSize: 11, color: 'var(--gray-500)', marginBottom: 2 }}>STROKES REC.</p>
                  <p style={{ fontSize: 22, fontWeight: 700, fontFamily: 'var(--font-mono)', color: 'var(--green-600)' }}>
                    +{strokesReceived(myPlayer.playing_handicap, currentHole.stroke_index)}
                  </p>
                </div>
              </div>
            )}

            {/* Score adjuster */}
            <div className="card" style={{ marginBottom: 16 }}>
              <p style={{ fontSize: 13, color: 'var(--gray-500)', marginBottom: 12, textAlign: 'center' }}>
                Hole {selectedHole} — your gross score
              </p>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 24, marginBottom: 8 }}>
                <button
                  onClick={() => setGrossScore(s => Math.max(1, s - 1))}
                  style={{ width: 48, height: 48, borderRadius: '50%', border: '1px solid var(--gray-300)', background: 'white', fontSize: 24, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                >
                  −
                </button>
                <div style={{ textAlign: 'center' }}>
                  <p style={{ fontSize: 56, fontWeight: 700, fontFamily: 'var(--font-mono)', lineHeight: 1, color: currentHole ? getScoreColor(grossScore, currentHole.par) : 'var(--gray-900)' }}>
                    {grossScore}
                  </p>
                </div>
                <button
                  onClick={() => setGrossScore(s => Math.min(20, s + 1))}
                  style={{ width: 48, height: 48, borderRadius: '50%', border: '1px solid var(--gray-300)', background: 'white', fontSize: 24, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                >
                  +
                </button>
              </div>
              {currentHole && (
                <p style={{ textAlign: 'center', fontSize: 14, color: 'var(--gray-500)', marginBottom: 4 }}>
                  {scoreLabel(grossScore, currentHole.par)}
                </p>
              )}
              {currentHole && myPlayer && (
                <p style={{ textAlign: 'center', fontSize: 13, color: 'var(--green-600)', fontWeight: 500 }}>
                  {stablefordPoints(grossScore, currentHole.par, currentHole.stroke_index, myPlayer.playing_handicap)} Stableford point{stablefordPoints(grossScore, currentHole.par, currentHole.stroke_index, myPlayer.playing_handicap) !== 1 ? 's' : ''}
                </p>
              )}
            </div>

            <button
              className="btn btn-primary"
              onClick={saveScore}
              disabled={saving}
              style={{ width: '100%', marginBottom: 8 }}
            >
              {saving ? 'Saving…' : `Save score for hole ${selectedHole}`}
            </button>
            {saveMsg && (
              <p style={{ textAlign: 'center', fontSize: 13, color: 'var(--green-600)', fontWeight: 500 }}>{saveMsg}</p>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
